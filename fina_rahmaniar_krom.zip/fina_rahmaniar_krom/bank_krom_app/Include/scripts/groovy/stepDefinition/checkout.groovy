package stepDefinition
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When



class checkout {
	@Given("I open the application")
	public void i_open_the_application() {
		WebUI.callTestCase(findTestCase('Pages/Login/lauch the app'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@Given("I tap on the login menu")
	public void i_tap_on_the_login_menu() {
		WebUI.callTestCase(findTestCase('Pages/Homepage/click login menu'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@Then("I should see the login page")
	public void i_should_see_the_login_page() {
		WebUI.callTestCase(findTestCase('Pages/Login/verify content'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@When("I enter username {string}")
	public void i_enter_username(String username) {
		WebUI.callTestCase(findTestCase('Pages/Login/set username'), [('username') : username], FailureHandling.STOP_ON_FAILURE)
	}
	
	@When("I enter password {string}")
	public void i_enter_password(String password) {
		WebUI.callTestCase(findTestCase('Pages/Login/set password'), [('password') : password], FailureHandling.STOP_ON_FAILURE)
	}
	
	@When("I tap on the login button")
	public void i_tap_on_the_login_button() {
		WebUI.callTestCase(findTestCase('Pages/Login/click login'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@Then("I should be redirected to the homepage")
	public void i_should_be_redirected_to_the_homepage() {
		WebUI.callTestCase(findTestCase('Pages/Homepage/verify content'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@When("Click product")
	public void click_product() {
		WebUI.callTestCase(findTestCase('Pages/Homepage/select product'), [:], FailureHandling.STOP_ON_FAILURE)	
	}
	
	@Then("I direct to cart page")
	public void i_direct_to_cart_page() {
		WebUI.callTestCase(findTestCase('Pages/Cart/verify content'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@When("I click add to cart")
	public void i_click_add_to_cart() {
		WebUI.callTestCase(findTestCase('Pages/Homepage/add to cart'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@Then("I direct to checkout page")
	public void i_direct_to_checkout_page() {
		WebUI.callTestCase(findTestCase('Pages/Checkout/verify content'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@When("I fill address info")
	public void i_fill_address_info() {
		WebUI.callTestCase(findTestCase('Pages/Checkout/fill the address info'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	
	@Then("should be direct to payment method")
	public void should_be_direct_to_payment_method() {
		WebUI.callTestCase(findTestCase('Pages/Checkout/verify content payment'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@When("I fill payment method")
	public void i_fill_payment_method() {
		WebUI.callTestCase(findTestCase('Pages/Checkout/fill payment method'), [:], FailureHandling.STOP_ON_FAILURE)
	}
	
	@Then("should be direct to review order")
	public void should_be_direct_to_review_order() {
		WebUI.callTestCase(findTestCase('Pages/Checkout/verify content review order'), [:], FailureHandling.STOP_ON_FAILURE)
	}
}