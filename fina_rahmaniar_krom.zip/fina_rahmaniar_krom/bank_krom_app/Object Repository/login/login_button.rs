<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>login_button</name>
   <tag></tag>
   <elementGuidId>3309f8bd-099f-493d-b0d5-1119e4cb2df6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.Button[@content-desc=&quot;Tap to login with given credentials&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.Button[@content-desc=&quot;Tap to login with given credentials&quot;]</value>
      <webElementGuid>a17122e9-026a-4b4c-8101-a7de25a6877a</webElementGuid>
   </webElementProperties>
</WebElementEntity>
