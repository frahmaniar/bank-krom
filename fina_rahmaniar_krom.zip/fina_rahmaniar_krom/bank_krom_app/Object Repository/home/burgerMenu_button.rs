<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>burgerMenu_button</name>
   <tag></tag>
   <elementGuidId>42d91ef7-2f16-467f-b350-8c47c6b3dd16</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.ImageView[@content-desc=&quot;View menu&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.ImageView[@content-desc=&quot;View menu&quot;]</value>
      <webElementGuid>9d658394-bef8-49fc-bdf2-2911c6b57ca9</webElementGuid>
   </webElementProperties>
</WebElementEntity>
