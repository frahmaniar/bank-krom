<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>productMenu_image</name>
   <tag></tag>
   <elementGuidId>a76fc639-aa46-4554-a4c9-902973ff1abd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//android.widget.ImageView[@content-desc=&quot;Product Image&quot;])[${index}]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//android.widget.ImageView[@content-desc=&quot;Product Image&quot;])[${index}]</value>
      <webElementGuid>5845b946-d799-44fa-bdc7-737c813c0efa</webElementGuid>
   </webElementProperties>
</WebElementEntity>
