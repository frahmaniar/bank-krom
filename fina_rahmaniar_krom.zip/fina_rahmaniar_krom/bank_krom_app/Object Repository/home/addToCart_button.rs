<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>addToCart_button</name>
   <tag></tag>
   <elementGuidId>e2016a71-37f7-4d6f-a8e6-4366ff6dafd3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.Button[@content-desc=&quot;Tap to add product to cart&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.Button[@content-desc=&quot;Tap to add product to cart&quot;]</value>
      <webElementGuid>4f9cb3d6-0c31-43c0-a4ce-be2c7da88b5f</webElementGuid>
   </webElementProperties>
</WebElementEntity>
