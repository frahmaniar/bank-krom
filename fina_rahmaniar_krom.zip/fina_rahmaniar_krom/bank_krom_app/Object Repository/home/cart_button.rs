<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>cart_button</name>
   <tag></tag>
   <elementGuidId>7e8e1094-933f-4f5e-8d26-356f6cd75497</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.RelativeLayout[@content-desc=&quot;View cart&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.RelativeLayout[@content-desc=&quot;View cart&quot;]</value>
      <webElementGuid>768fe265-f448-4957-9f6f-c960c5e5cc2c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
