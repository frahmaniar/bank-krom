<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>titleProductMenu_text</name>
   <tag></tag>
   <elementGuidId>da171102-8575-4656-b9e1-e4ba234027c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>(//android.widget.ImageView[@content-desc=&quot;Product Image&quot;])[${index}]/following-sibling::android.widget.TextView[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>(//android.widget.ImageView[@content-desc=&quot;Product Image&quot;])[${index}]/following-sibling::android.widget.TextView[1]</value>
      <webElementGuid>b00f928a-7977-41e0-8fc7-6c0b0d18153e</webElementGuid>
   </webElementProperties>
</WebElementEntity>
