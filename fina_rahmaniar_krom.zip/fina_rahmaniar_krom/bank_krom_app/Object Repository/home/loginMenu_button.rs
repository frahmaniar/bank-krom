<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>loginMenu_button</name>
   <tag></tag>
   <elementGuidId>103b767e-6eab-4a58-a2d1-9d67a9e14b7d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.TextView[@content-desc=&quot;Login Menu Item&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.TextView[@content-desc=&quot;Login Menu Item&quot;]</value>
      <webElementGuid>c11cd5f4-b6bf-4467-8615-c3c3eab59556</webElementGuid>
   </webElementProperties>
</WebElementEntity>
