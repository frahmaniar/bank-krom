<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>payment_button</name>
   <tag></tag>
   <elementGuidId>f1e4122a-05f0-442b-aaac-02428965405d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.Button[@content-desc=&quot;Saves user info for checkout&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.Button[@content-desc=&quot;Saves user info for checkout&quot;]</value>
      <webElementGuid>cbdf0852-57e2-4fd3-b8f7-b3bdf61ff310</webElementGuid>
   </webElementProperties>
</WebElementEntity>
