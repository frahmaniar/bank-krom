<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>removeItem_button</name>
   <tag></tag>
   <elementGuidId>0767229a-41ce-437b-8230-3ee289fa6ff2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.TextView[@content-desc=&quot;Removes product from cart&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.TextView[@content-desc=&quot;Removes product from cart&quot;]</value>
      <webElementGuid>968fbd2a-f09f-4873-898b-29af0aa204b2</webElementGuid>
   </webElementProperties>
</WebElementEntity>
