<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>openCatalog_button</name>
   <tag></tag>
   <elementGuidId>30cbbb55-18e8-4eda-a79a-ef46e7254468</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.Button[@content-desc=&quot;Tap to open catalog&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.Button[@content-desc=&quot;Tap to open catalog&quot;]</value>
      <webElementGuid>0fa1393e-1198-4f5b-92f0-6f254c838d79</webElementGuid>
   </webElementProperties>
</WebElementEntity>
