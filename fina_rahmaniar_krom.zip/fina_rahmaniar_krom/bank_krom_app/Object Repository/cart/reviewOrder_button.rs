<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>reviewOrder_button</name>
   <tag></tag>
   <elementGuidId>91360dde-2adf-4adf-ae91-e8d0d1ffdb23</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.Button[@content-desc=&quot;Saves payment info and launches screen to review checkout data&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.Button[@content-desc=&quot;Saves payment info and launches screen to review checkout data&quot;]</value>
      <webElementGuid>1c93c73c-0fdb-426c-b08c-986dd1f91aef</webElementGuid>
   </webElementProperties>
</WebElementEntity>
