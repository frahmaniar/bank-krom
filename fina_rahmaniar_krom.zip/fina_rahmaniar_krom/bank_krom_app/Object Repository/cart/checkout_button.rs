<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkout_button</name>
   <tag></tag>
   <elementGuidId>26676b8a-7769-48d9-a163-080ca6e00947</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.Button[@content-desc=&quot;Confirms products for checkout&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.Button[@content-desc=&quot;Confirms products for checkout&quot;]</value>
      <webElementGuid>006f8cf5-7ed1-4b66-b351-7d07fbdf234c</webElementGuid>
   </webElementProperties>
</WebElementEntity>
