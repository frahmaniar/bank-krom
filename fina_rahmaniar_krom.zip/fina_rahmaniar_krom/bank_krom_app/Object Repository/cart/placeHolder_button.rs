<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>placeHolder_button</name>
   <tag></tag>
   <elementGuidId>e0cebc12-ebf0-4066-81f4-dd37ee9e9559</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//android.widget.Button[@content-desc=&quot;Completes the process of checkout&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//android.widget.Button[@content-desc=&quot;Completes the process of checkout&quot;]</value>
      <webElementGuid>d238d421-9ba8-400d-97f3-12fcd5015bd9</webElementGuid>
   </webElementProperties>
</WebElementEntity>
