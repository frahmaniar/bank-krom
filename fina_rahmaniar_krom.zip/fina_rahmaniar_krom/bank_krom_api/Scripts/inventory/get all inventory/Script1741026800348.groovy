import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.TestObjectProperty
import groovy.json.JsonSlurper
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import org.junit.Assert

RequestObject request = ObjectRepository.findTestObject('API/GET')
request.setRestUrl("https://petstore.swagger.io/v2/store/inventory")

request.setHttpHeaderProperties([
    new TestObjectProperty("accept", ConditionType.EQUALS, "application/json")
])

ResponseObject response = WS.sendRequest(request)

WS.verifyResponseStatusCode(response, 200)

def jsonResponse = new JsonSlurper().parseText(response.getResponseBodyContent())

assert jsonResponse."sold " != null
assert jsonResponse."pending adoption" != null
assert jsonResponse."test_status2503031756" != null
assert jsonResponse."test_status2503031800" != null
assert jsonResponse."test_status2503031742" != null
assert jsonResponse."test_status2503031743" != null
assert jsonResponse."test_status2503031739" != null
assert jsonResponse."test_status2503031759" != null
assert jsonResponse."test_status2503031738" != null
assert jsonResponse."available, sold" != null
assert jsonResponse."test_status2503031757" != null
assert jsonResponse."test_status2503031747" != null
assert jsonResponse."test_status2503031758" != null
assert jsonResponse."test_status2503031802" != null
assert jsonResponse."new_status2402" != null