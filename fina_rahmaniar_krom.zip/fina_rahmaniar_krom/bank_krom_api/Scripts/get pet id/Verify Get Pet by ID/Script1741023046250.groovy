import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.TestObjectProperty
import groovy.json.JsonSlurper
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import org.junit.Assert

def id = 2
RequestObject request = ObjectRepository.findTestObject('API/GET')
request.setRestUrl("https://petstore.swagger.io/v2/pet/${id}")

request.setHttpHeaderProperties([
    new TestObjectProperty("accept", ConditionType.EQUALS, "application/json")
])

ResponseObject response = WS.sendRequest(request)

WS.verifyResponseStatusCode(response, 200)

def jsonResponse = new JsonSlurper().parseText(response.getResponseBodyContent())

// assertion data type
Assert.assertTrue(jsonResponse.id instanceof Integer)                 
Assert.assertTrue(jsonResponse.category instanceof Map)              
Assert.assertTrue(jsonResponse.category.id instanceof Integer) 
Assert.assertTrue(jsonResponse.category.name instanceof String)     
Assert.assertTrue(jsonResponse.name instanceof String)               
Assert.assertTrue(jsonResponse.photoUrls instanceof List)            
Assert.assertTrue(jsonResponse.photoUrls[0] instanceof String)      
Assert.assertTrue(jsonResponse.tags instanceof List)                 
Assert.assertTrue(jsonResponse.tags[0] instanceof Map)               
Assert.assertTrue(jsonResponse.tags[0].id instanceof Integer)        
Assert.assertTrue(jsonResponse.tags[0].name instanceof String)       
Assert.assertTrue(jsonResponse.status instanceof String)          

// assertion value
assert jsonResponse.id == id
assert jsonResponse.name == "miperro"
assert jsonResponse.status == "available"
