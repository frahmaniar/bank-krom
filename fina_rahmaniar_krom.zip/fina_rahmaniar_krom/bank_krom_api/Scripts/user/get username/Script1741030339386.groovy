import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.TestObjectProperty
import groovy.json.JsonSlurper
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import org.junit.Assert

def username = "frniar" 

RequestObject request = ObjectRepository.findTestObject('API/GET')
request.setRestUrl("https://petstore.swagger.io/v2/user/${username}")

request.setHttpHeaderProperties([
	new TestObjectProperty("accept", ConditionType.EQUALS, "application/json")
])

ResponseObject response = WS.sendRequest(request)

WS.verifyResponseStatusCode(response, 200)

def jsonResponse = new JsonSlurper().parseText(response.getResponseBodyContent())

assert jsonResponse.username == username
assert jsonResponse.firstName != null
assert jsonResponse.lastName != null
assert jsonResponse.email != null
assert jsonResponse.password != null
assert jsonResponse.phone != null
assert jsonResponse.userStatus == 1