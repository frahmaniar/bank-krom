
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */



def static "utilities.randomString"(
    	int length	) {
    (new utilities()).randomString(
        	length)
}


def static "utilities.randomInteger"(
    	int min	
     , 	int max	) {
    (new utilities()).randomInteger(
        	min
         , 	max)
}


def static "utilities.randomString"() {
    (new utilities()).randomString()
}
